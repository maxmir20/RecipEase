(function() {

    function findRecipe(){
        let ingredient = document.querySelector('div[class*="ingredient"]');
        ingredient.scrollIntoView(true);
    }
    
    browser.runtime.onMessage.addListener((message) => {
        if (message.command === "findRecipe") {
            findRecipe();
        } 
    });
})
undefined
